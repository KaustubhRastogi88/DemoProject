//
//  ModelProductDetails.swift
//  ProjectProductTask
//
//  Created by Kaustubh Rastogi on 18/03/23.
//

import Foundation

class DetailsViewModel : NSObject{
    var reloadTableView: (() -> Void)?
    var CallBack: (() -> Void)?
    var details: ProductListData?{
        didSet{
            reloadTableView?()
        }
    }
    
    
    
   
    
    
    func listProduct(id:String) {
        guard let url = URL(string: "https://fakestoreapi.com/products/\(id)") else { return }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"

        request.allHTTPHeaderFields = [
            "Content-Type": "application/json"
        ]

        URLSession.shared.dataTask(with: request) { data, response, error in
          
            do {
              
                let response = try JSONDecoder().decode(ProductListData.self, from: data!)
                self.details = response
                print(self.details)
            }catch {
                print(error)
            }
        }.resume()
    }
    
    func deleteProduct(id:String) {
        guard let url = URL(string: "https://fakestoreapi.com/products/\(id)") else { return }

        var request = URLRequest(url: url)
        request.httpMethod = "DELETE"

        request.allHTTPHeaderFields = [
            "Content-Type": "application/json"
        ]

        URLSession.shared.dataTask(with: request) { data, response, error in
          
            do {
              
                let response = try JSONDecoder().decode(ProductListData.self, from: data!)
                self.details = response
                self.CallBack?()
                print(self.details)
            }catch {
                print(error)
            }
        }.resume()
    }
}
