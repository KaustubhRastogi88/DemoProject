//
//  ProductDetailsTableViewCell.swift
//  ProjectProductTask
//
//  Created by Kaustubh Rastogi on 18/03/23.
//

import UIKit

class ProductDetailsTableViewCell: UITableViewCell {

    @IBOutlet weak var buttonUpdate: UIButton!
    
    @IBOutlet weak var buttonDelete: UIButton!
    @IBOutlet weak var labelTitile: UILabel!
    
    @IBOutlet weak var imgs: UIImageView!
    
    @IBOutlet weak var labelDescription: UILabel!
    
    @IBOutlet weak var labelCategary: UILabel!
    
    @IBOutlet weak var labelPrice: UILabel!
    
    @IBOutlet weak var labelRate: UILabel!
    
    @IBOutlet weak var labelCount: UILabel!
    
    var product : ProductListData?{
        didSet{
            productDetailsTypes()
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func productDetailsTypes() {
        guard let title = product?.title ,
              let cat = product?.category,
                let desc = product?.description,
                let count = product?.rating.count,
              let rate = product?.rating.rate,
              let price = product?.price else {
            return
        }
        labelTitile.text = title
        labelCategary.text = "Catagory: " + cat
        labelDescription.text = desc
        labelCount.text = "Product Count: " + "\(String(describing: count))"
        labelPrice.text = "Price: $\(price)"
        labelRate.text =  "Rate: " + "\(rate)"
        imgs.downlodeImage(serviceurl: product?.image ?? "", placeHolder: UIImage(named: ""))
    }
}
