//
//  ProductTypeTableViewCell.swift
//  ProjectProductTask
//
//  Created by Kaustubh Rastogi on 18/03/23.
//

import UIKit

class ProductTypeTableViewCell: UITableViewCell {
    @IBOutlet weak var labelTitle: UILabel!
    
    @IBOutlet weak var labelPrice: UILabel!
    
    @IBOutlet weak var labelRate: UILabel!
    
    @IBOutlet weak var labelSubTitle: UILabel!
    
    @IBOutlet weak var imgProduct: UIImageView!
    var productType: ProductListData? {
        didSet { // Property Observer
            productDetailsTypes()
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    func productDetailsTypes() {
        guard let title = productType?.title ,
              let cat = productType?.category,
              let rate = productType?.rating.rate,
              let price = productType?.price else {
            return
        }
        labelTitle.text = title
        labelSubTitle.text = cat
        labelPrice.text = "Price: $\(price)"
        labelRate.text =  "Rate: " + "\(rate)"
        imgProduct.downlodeImage(serviceurl: productType?.image ?? "", placeHolder: UIImage(named: ""))
    }
    
}
