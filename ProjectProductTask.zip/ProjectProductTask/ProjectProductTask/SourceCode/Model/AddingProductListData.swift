//
//  AddingProductListData.swift
//  ProjectProductTask
//
//  Created by Kaustubh Rastogi on 18/03/23.
//

import Foundation

struct AddingProductListData: Codable {
    var id: Int? = nil
    var title: String
    var price: String
    var description:String
    var category : String
}
