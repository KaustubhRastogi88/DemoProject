//
//  ProductListData.swift
//  ProjectProductTask
//
//  Created by Kaustubh Rastogi on 18/03/23.
//

import Foundation


struct ProductListData: Codable {
    var id: Int
    var title: String
    var price: Double
    var description: String
    var category: String
    var image: String
    var rating: Rate
}

struct Rate: Codable {
    var rate: Double
    var count: Int
}
