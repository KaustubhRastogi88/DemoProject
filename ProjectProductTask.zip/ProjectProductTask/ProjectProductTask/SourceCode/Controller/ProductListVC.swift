//
//  ProductListVC.swift
//  ProjectProductTask
//
//  Created by Kaustubh Rastogi on 18/03/23.
//

import UIKit

class ProductListVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    

    lazy var listModel = {
        ListTypeModel()
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        initModelProduct()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        configuration()
        // Do any additional setup after loading the view.
    }
    

    @IBAction func buttonAddTapped(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ProductListAddVC") as! ProductListAddVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension ProductListVC {

    func configuration() {
        tableView.register(UINib(nibName: "ProductTypeTableViewCell", bundle: nil), forCellReuseIdentifier: "ProductTypeTableViewCell")
        
       
    }

    func initModelProduct() {
        listModel.listProduct()
        listModel.reloadTableView = { [weak self] in
           
            DispatchQueue.main.async {
                self?.tableView.reloadData()
            }
            
        }
    }

   

}

extension ProductListVC: UITableViewDelegate, UITableViewDataSource {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listModel.list.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "ProductTypeTableViewCell") as? ProductTypeTableViewCell else {
            return UITableViewCell()
        }
        let product = listModel.list[indexPath.row]
        cell.productType = product
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ProductDetailTypeVC") as! ProductDetailTypeVC
        vc.id = "\(listModel.list[indexPath.row].id)"
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

