//
//  ProductListAddVC.swift
//  ProjectProductTask
//
//  Created by Kaustubh Rastogi on 18/03/23.
//

import UIKit

class ProductListAddVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var textFieldDescription: UITextField!
    @IBOutlet weak var labelProductHead: UILabel!
    
    @IBOutlet weak var textFieldTitle: UITextField!
    @IBOutlet weak var textFieldCategory: UITextField!
    @IBOutlet weak var textFieldPrice: UITextField!
    @IBOutlet weak var imageAdd: UIImageView!
    
    var product: ProductListData?
    var addModel : AddUpdateViewModel = AddUpdateViewModel()
    override func viewDidLoad() {
        super.viewDidLoad()
        initialSetup()
        configurationData()
        
    }
//    override func viewDidLayoutSubviews() {
//        super.viewDidLayoutSubviews()
//
//        guard let headerView = tableView.tableHeaderView else {
//            return
//        }
//        let size = headerView.systemLayoutSizeFitting(UIView.layoutFittingCompressedSize)
//        if headerView.frame.size.height != size.height {
//            headerView.frame.size.height = size.height
//            tableView.tableHeaderView = headerView
//            tableView.layoutIfNeeded()
//        }
//
//    }
//
    
    
    @IBAction func buttonDoneTapped(_ sender: UIButton) {
        didEnter()
    }
    
    func didEnter(){
        let price = self.textFieldPrice.text ?? ""
        let cat = self.textFieldCategory.text ?? ""
        let title = self.textFieldTitle.text ?? ""
        let desc = self.textFieldDescription.text ?? ""
        addModel.doAdd(title: title, price: price, desc: desc, cat: cat)
        addModel.callBack = { [weak self] in
            DispatchQueue.main.async {
                for controller in (self?.navigationController!.viewControllers)! as Array {
                    if controller.isKind(of: ProductListVC.self) {
                        self?.navigationController!.popToViewController(controller, animated: true)
                       
                        return
                    }
                }
                
            }
        }
    }

    func configurationData(){
        guard let title = product?.title ,
              let cat = product?.category,
                let desc = product?.description,
              let price = product?.price else {
            return
        }
        self.labelProductHead.text = "Update Product"
        self.textFieldTitle.text = title
        self.textFieldDescription.text =  desc
        self.textFieldCategory.text = cat
        self.textFieldPrice.text = "\(price)"
        imageAdd.downlodeImage(serviceurl: product?.image ?? "", placeHolder: UIImage(named: ""))
    }
    
    func initialSetup(){
        imageAdd.layer.cornerRadius = 5
        imageAdd.layer.borderColor = UIColor.darkGray.cgColor
        imageAdd.layer.borderWidth = 1
       
    }

}


