//
//  ModelProductList.swift
//  ProjectProductTask
//
//  Created by Kaustubh Rastogi on 18/03/23.
//

import Foundation

class ListTypeModel : NSObject{
    var reloadTableView: (() -> Void)?
    
    var list = [ProductListData](){
        didSet{
            reloadTableView?()
        }
    }
    
    
    
   
    
    
    func listProduct() {
        guard let url = URL(string: "https://dummyjson.com/products/1") else { return }
       // guard let url = URL(string: "https://fakestoreapi.com/products") else { return }
        //https://dummyjson.com/products/1

        var request = URLRequest(url: url)
        request.httpMethod = "GET"

        request.allHTTPHeaderFields = [
            "Content-Type": "application/json"
        ]

        URLSession.shared.dataTask(with: request) { data, response, error in
          
            do {
              
                let response = try JSONDecoder().decode([ProductListData].self, from: data!)
                self.list = response
                print(self.list)
            }catch {
                print(error)
            }
        }.resume()
    }
    
}

extension ListTypeModel {
    
    enum Event {
        case loading
        case stopLoading
        case dataLoaded
        case error(Error?)
        case newProductAdded(product: AddingProductListData)
    }
    
}
